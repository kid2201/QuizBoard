package quizboard.client;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import quizboard.model.Answer;

public class frmQuiz {

	private JPanel contentPane;
	private JFrame frame;
	private JPanel panel;
	private ArrayList<Color> btnColors;
	private JLabel lblScore;
	private JLabel lblTime;
	
	/**
	 * Create the frame.
	 */
	public frmQuiz() {
		
		btnColors = new ArrayList<Color>();
		btnColors.add(new Color(19,104,206));
		btnColors.add(new Color(226,27,60));
		btnColors.add(new Color(216,158,0));
		btnColors.add(new Color(38,137,12));
		
		//--------- MAIN PANEL ----------
		contentPane = new JPanel();
		contentPane.setBackground(new Color(75, 56, 210));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		//--------- MAIN PANEL ----------
		
		//--------- INIT FRAME ----------
		frame = new JFrame("Quiz Board");		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 296, 502);
		frame.setLocation(950, 200);
		frame.setContentPane(contentPane);
		contentPane.setLayout(null);
		//--------- INIT FRAME ----------
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(23, 39, 253, 397);
		contentPane.add(scrollPane);
		
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		scrollPane.setViewportView(panel);
		panel.setLayout(new GridLayout(0, 1, 0, 0));
				
		lblTime = new JLabel("");
		lblTime.setFont(new Font("Helvetica", Font.PLAIN, 15));
		lblTime.setForeground(Color.WHITE);
		lblTime.setHorizontalAlignment(SwingConstants.CENTER);
		lblTime.setBounds(23, 9, 253, 22);
		contentPane.add(lblTime);
		
		lblScore = new JLabel("Score: 0");
		lblScore.setFont(new Font("Helvetica", Font.PLAIN, 15));
		lblScore.setForeground(Color.WHITE);
		lblScore.setBounds(23, 448, 61, 16);
		contentPane.add(lblScore);
	}
	
	public JLabel getLblTime() {
		return lblTime;
	}

	public void setLblTime(JLabel lblTime) {
		this.lblTime = lblTime;
	}

	public JLabel getLblScore() {
		return lblScore;
	}

	public void setLblScore(JLabel lblScore) {
		this.lblScore = lblScore;
	}

	public JPanel getContentPane() {
		return contentPane;
	}

	public void setContentPane(JPanel contentPane) {
		this.contentPane = contentPane;
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public JPanel getPanel() {
		return panel;
	}

	public void setPanel(JPanel panel) {
		this.panel = panel;
	}

	public ArrayList<Color> getBtnColors() {
		return btnColors;
	}

	public void setBtnColors(ArrayList<Color> btnColors) {
		this.btnColors = btnColors;
	}

	public JButton addAnswer(Answer answer) {
		int ind = panel.getComponentCount() + 1;
		JButton btnAnswer = new JButton(ind+" - "+answer.getAnswer());
		btnAnswer.setFont(new Font("Helvetica", Font.PLAIN, 20));
		btnAnswer.setForeground(new Color(255, 255, 255));
		btnAnswer.setBackground(btnColors.get(ind % 4));
		btnAnswer.setOpaque(true);
		btnAnswer.setBorderPainted(false);
		panel.add(btnAnswer);
		panel.revalidate();
		
		return btnAnswer;
	}
}

package quizboard.client;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

public class frmIndex {

	private JPanel contentPane;
	private JFrame frame;
	private JTextField txtQuizID;
	private JButton btnStart;
	private JTextField txtName;
	private JLabel lblStatus;
	
	public JLabel getLblStatus() {
		return lblStatus;
	}

	public void setLblStatus(JLabel lblStatus) {
		this.lblStatus = lblStatus;
	}

	/**
	 * Create the frame.
	 */
	public frmIndex() {
		//--------- MAIN PANEL ----------
		contentPane = new JPanel();
		contentPane.setBackground(new Color(75, 56, 210));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		//--------- MAIN PANEL ----------
		
		//--------- INIT FRAME ----------
		frame = new JFrame("Quiz Board");		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 642, 220);
		frame.setLocationRelativeTo(null);
		frame.setContentPane(contentPane);
		//--------- INIT FRAME ----------
		
		//--------- LABEL TITLE ---------
		JLabel lblQuizBoard = new JLabel("QUIZ BOARD");
		lblQuizBoard.setForeground(new Color(255, 255, 255));
		lblQuizBoard.setFont(new Font("Helvetica", Font.PLAIN, 20));
		lblQuizBoard.setHorizontalAlignment(SwingConstants.CENTER);
		lblQuizBoard.setBounds(251, 10, 130, 33);
		contentPane.add(lblQuizBoard);
		//--------- LABEL TITLE ---------		
		
		//------- Panel QUIZ START ---------
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(75, 56, 210));
		panel_2.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_2.setBounds(57, 45, 526, 113);
		contentPane.add(panel_2);

		txtQuizID = new JTextField();
		txtQuizID.setText("QUIZ ID");
		txtQuizID.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(txtQuizID);
		txtQuizID.setColumns(45);
		
		txtName = new JTextField();
		txtName.setText("NAME");
		txtName.setHorizontalAlignment(SwingConstants.CENTER);
		txtName.setColumns(45);
		panel_2.add(txtName);
		
		btnStart = new JButton("Start");
		btnStart.setForeground(new Color(255, 255, 255));
		btnStart.setBackground(new Color(253, 174, 92));
		btnStart.setOpaque(true);
		btnStart.setBorderPainted(false);
		panel_2.add(btnStart);
		
		lblStatus = new JLabel("");
		lblStatus.setFont(new Font("Helvetica", Font.PLAIN, 15));
		lblStatus.setForeground(Color.WHITE);
		lblStatus.setBounds(57, 170, 526, 16);
		contentPane.add(lblStatus);

		
		//------- Panel QUIZ START ---------
	}

	public JPanel getContentPane() {
		return contentPane;
	}

	public void setContentPane(JPanel contentPane) {
		this.contentPane = contentPane;
	}

	public JTextField getTxtName() {
		return txtName;
	}

	public void setTxtName(JTextField txtName) {
		this.txtName = txtName;
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public JTextField getTxtQuizID() {
		return txtQuizID;
	}

	public void setTxtQuizID(JTextField txtQuizID) {
		this.txtQuizID = txtQuizID;
	}

	public JButton getBtnStart() {
		return btnStart;
	}

	public void setBtnStart(JButton btnStart) {
		this.btnStart = btnStart;
	}
}

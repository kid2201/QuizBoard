package quizboard.client.controller;

import static javax.swing.JOptionPane.showMessageDialog;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.Timer;

import quizboard.client.frmQuiz;
import quizboard.model.Answer;

public class QuizController {
	private frmQuiz view;
	private Socket socket;
	private Timer timer; 
	private int currentQuestionID;
	private int score;
	private DataOutputStream dOS;
	private String userName;
	
	public int getCurrentQuestionID() {
		return currentQuestionID;
	}

	public void setCurrentQuestionID(int currentQuestionID) {
		this.currentQuestionID = currentQuestionID;
	}

	public QuizController(String userName, Socket socket)
	{
		this.userName = userName;
		this.score = 0;
		this.socket = socket;
		try {
			this.dOS = new DataOutputStream(this.socket.getOutputStream());
		} catch(IOException e) {
			e.printStackTrace();
		}
		view = new frmQuiz();
	}
	
	public void initView()
	{
		view.getFrame().setVisible(true);
		waitingForNewQuestion();
	}
	
	public void init()
	{	
	}
	
	public void setQuestionTime(int time)
	{
		timer = new Timer(1000, new ActionListener() {
			int count = time;
			@Override
			public void actionPerformed(ActionEvent e) {
				if(count >= 0) {
					view.getLblTime().setText("Starting answer in "+ count + "s");
				} else {
					((Timer) (e.getSource())).stop();
				}
				count--;
			}
			
		});
		
		timer.setInitialDelay(0);
		timer.start();
	}
	
	public void setAnswerTime(int time)
	{
		timer = new Timer(1000, new ActionListener() {
			int count = time;
			@Override
			public void actionPerformed(ActionEvent e) {
				if(count >= 0) {
					view.getLblTime().setText("Answer time: "+count+"s");;
				} else {
					stopTimer();
				}
				count--;
			}
			
		});
		
		timer.setInitialDelay(0);
		timer.start();
	}
	
	public void stopTimer()
	{
		if(timer != null && timer.isRunning()) timer.stop();
		view.getLblTime().setText("Answering finished!");;
		waitingForNewQuestion();
	}
	
	public void addAnswer(int answer_ID, int question_ID, String answerContent, boolean isAnswer)
	{
		Answer answer = new Answer(answer_ID, question_ID, answerContent, isAnswer); 
		JButton btnAnswer = view.addAnswer(answer);
		btnAnswer.addActionListener(e -> {
			try {
				answerClicked(answer);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
	}
	
	public void sendMsgToSever(String msg) {
		try {
			dOS.writeUTF(msg);
			dOS.flush();
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public void answerClicked(Answer answer) throws SQLException {
		sendMsgToSever("answerQuestion@@@"+this.userName+"###"+answer.getID());

		if(answer.isAnswer()) {
			showMessageDialog(null, "Right answer!!!");
			score += answer.getQuestion().getScore();
			view.getLblScore().setText("Score: "+score);
		} else {
			showMessageDialog(null, "Wrong answer...");
		}
		stopTimer();
	}
	
	public void waitingForNewQuestion() {
		for(Component component : view.getPanel().getComponents())
		{
			view.getPanel().remove(component);
		}
		
		view.getPanel().revalidate();
		view.getPanel().repaint();
	}
}

package quizboard.client.controller;

import static javax.swing.JOptionPane.showMessageDialog;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.Timer;

import quizboard.client.frmIndex;

public class IndexController {
	private frmIndex view;
	private Timer timer;
	private Socket socket;
	private String quizID;
	private String userName;
	private DataOutputStream dOS;

	public IndexController()
	{
		view = new frmIndex();
		initView();
	}
	
	public void initView()
	{
		view.getFrame().setVisible(true);
	}
	
	public void init()
	{
		view.getBtnStart().addActionListener(e -> findChanel(view.getTxtName().getText(),view.getTxtQuizID().getText()));
	}
	
	public void stopTimer() {
		if(timer.isRunning()) timer.stop();
		view.getLblStatus().setText("Status: Connect to "+view.getTxtQuizID().getText()+" chanel sucuessfully");
		this.view.getFrame().dispose();
	}
	
	public void findChanel(String name, String quizID)
	{
		if(!quizID.isBlank() && !name.isBlank()) {
			this.userName = name;
			this.quizID = quizID;
			
			try {
				socket = new Socket("localhost",3333);
				dOS = new DataOutputStream(socket.getOutputStream());
				try {
					dOS.writeUTF("checkOpen@@@"+this.userName+"###"+this.quizID);
					dOS.flush();
					
					ThreadMessageReciever threadMessageReceiver = new ThreadMessageReciever(userName, socket,this);
					threadMessageReceiver.start();
					
					timer = new Timer(1000, new ActionListener() {
						int count = 10;
						@Override
						public void actionPerformed(ActionEvent e) {
							if(count >= 0) {
								if(count == 10)
								{
									view.getBtnStart().setVisible(false);
									view.getLblStatus().setText("Status: Checking connection to "+view.getTxtQuizID().getText()+" chanel");
								} 
								view.getLblStatus().setText(view.getLblStatus().getText()+".");
							} else {
								((Timer) (e.getSource())).stop();
								view.getBtnStart().setVisible(true);
								view.getLblStatus().setText("Can not connect to chanel... Try again later!");
							}
							count--;
						}
						
					});
					
					timer.setInitialDelay(0);
					timer.start();
					
				} catch(IOException e) {
					showMessageDialog(null, e.getMessage());
				}
			} catch(UnknownHostException e) {
				showMessageDialog(null, e.getMessage());
			} catch(IOException e) {
				showMessageDialog(null, e.getMessage());
			}

		} else {
			showMessageDialog(null, "Please input the Quiz ID!");
		}
	}
}

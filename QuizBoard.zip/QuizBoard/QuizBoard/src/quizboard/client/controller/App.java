package quizboard.client.controller;

import quizboard.client.controller.IndexController;

public class App {
	public static void main(String[] args) {
		IndexController controller = new IndexController();
		controller.init();
	}
}
